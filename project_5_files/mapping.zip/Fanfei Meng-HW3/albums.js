// CS 330 - Homework 3 starter code

// This is the JSON (JavaScript Object Notation) object that stores all of our 
// album information. 
var albums = [
 
  {
    title : "Detailed Mapping",
    artist : "Second Floor",
    cover : "images/tech-map-second-floor-large.png",
    tracks : [
      "Yesterday",
      "Sunny Duet",
      "Diddy Bop",
      "All I Need",
      "Reality Check",
      "Freedom Interlude",
      "Casket Pretty",
      "Forever",
      "Bye Bye Baby",
      "Shadow Man"
    ]
  },
  
  
];


// Fill in this function to dyamically construct the HTML elements for the album list
function buildAlbumList() {
  var albumList = document.getElementById("album-list");
  if (albumList != null) {
for (var i=0; i<albums.length; i++){
var albumDiv = document.createElement('div');
albumDiv.classList.add('albums-album-wrapper');
var multline = 
`<image class="albums-album-art" src="${albums[i].cover}">
<div class="albums-album-name">${albums[i].title}</div>
<div class="albums-artist-name">${albums[i].artist}<p></div>`;
albumDiv.innerHTML = multline;
albumList.appendChild(albumDiv);
}
}
}